package dev.kxki.keyapp;

import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.inputmethod.InputConnection;

public class KeyAppImeService extends InputMethodService implements KeyboardView.OnKeyboardAction {
    @Override
    public View onCreateInputView() {
        KeyboardView view = new KeyboardView(this);
        view.setAction(this);
        return view;
    }

    @Override
    public void commit(String text) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(text, 1);
    }

    @Override
    public void backspace() {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.deleteSurroundingText(1, 0);
    }

    @Override
    public void enter() {
        commit("\n");
    }
}
