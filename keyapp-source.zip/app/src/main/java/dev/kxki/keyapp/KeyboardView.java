package dev.kxki.keyapp;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class KeyboardView extends View {
    public interface OnKeyboardAction {
        void commit(String text);
        void backspace();
        void enter();
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Key> keys = new ArrayList<>();
    private OnKeyboardAction action;
    private boolean japanese = false;
    private boolean clipboard = false;
    private float keyboardHeightDp = 260f;
    private Key downKey;
    private float downX, downY;

    private static class Key {
        RectF r;
        String label;
        String value;
        Key(float l, float t, float rr, float b, String label, String value) {
            this.r = new RectF(l, t, rr, b);
            this.label = label;
            this.value = value;
        }
    }

    public KeyboardView(Context context) {
        super(context);
        setMinimumHeight(dp(keyboardHeightDp));
        setBackgroundColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 31) setRenderEffect(null);
    }

    public void setAction(OnKeyboardAction action) { this.action = action; }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int h = dp(keyboardHeightDp);
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), h);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        buildKeys(getWidth(), getHeight());

        paint.setColor(Color.argb(210, 242, 242, 247));
        c.drawRoundRect(new RectF(8, 8, getWidth() - 8, getHeight() - 8), dp(24), dp(24), paint);

        for (Key k : keys) {
            paint.setColor(k == downKey ? Color.argb(255, 200, 200, 210) : Color.argb(235, 255, 255, 255));
            c.drawRoundRect(k.r, dp(12), dp(12), paint);
            paint.setColor(Color.rgb(25, 25, 30));
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(k.label.length() > 2 ? 14 : 18));
            Paint.FontMetrics fm = paint.getFontMetrics();
            float cy = k.r.centerY() - (fm.ascent + fm.descent) / 2;
            c.drawText(k.label, k.r.centerX(), cy, paint);
        }
    }

    private void buildKeys(int w, int h) {
        keys.clear();
        float gap = dp(6), top = dp(12);
        if (clipboard) {
            addRow(w, top, new String[]{"Paste", "Clear", "ABC", "かな"}, new String[]{"#paste", "#clear", "#en", "#jp"});
            return;
        }
        if (japanese) buildJp(w, top, gap); else buildQwerty(w, top, gap);
    }

    private void buildQwerty(int w, float top, float gap) {
        addRow(w, top, split("qwertyuiop"), split("qwertyuiop"));
        addRow(w, top + dp(50), split("asdfghjkl"), split("asdfghjkl"));
        addRow(w, top + dp(100), new String[]{"⇧","z","x","c","v","b","n","m","⌫"}, new String[]{"#shift","z","x","c","v","b","n","m","#del"});
        addRow(w, top + dp(150), new String[]{"かな","clip","space","return"}, new String[]{"#jp","#clip"," ","#enter"});
    }

    private void buildJp(int w, float top, float gap) {
        addRow(w, top, new String[]{"あ","か","さ"}, new String[]{"あ","か","さ"});
        addRow(w, top + dp(50), new String[]{"た","な","は"}, new String[]{"た","な","は"});
        addRow(w, top + dp(100), new String[]{"ま","や","ら"}, new String[]{"ま","や","ら"});
        addRow(w, top + dp(150), new String[]{"ABC","わ","、。","⌫"}, new String[]{"#en","わ","。","#del"});
        addRow(w, top + dp(200), new String[]{"clip","space","return","resize"}, new String[]{"#clip"," ","#enter","#resize"});
    }

    private void addRow(int w, float y, String[] labels, String[] values) {
        float gap = dp(6), x = dp(12);
        float keyW = (w - dp(24) - gap * (labels.length - 1)) / labels.length;
        for (int i = 0; i < labels.length; i++) {
            keys.add(new Key(x, y, x + keyW, y + dp(42), labels[i], values[i]));
            x += keyW + gap;
        }
    }

    private String[] split(String s) {
        String[] out = new String[s.length()];
        for (int i = 0; i < s.length(); i++) out[i] = String.valueOf(s.charAt(i));
        return out;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            downX = e.getX(); downY = e.getY();
            downKey = findKey(downX, downY);
            invalidate();
            return true;
        }
        if (e.getAction() == MotionEvent.ACTION_UP) {
            Key k = downKey;
            downKey = null;
            invalidate();
            if (k != null) handle(k, e.getX() - downX, e.getY() - downY);
            return true;
        }
        return true;
    }

    private Key findKey(float x, float y) {
        for (Key k : keys) if (k.r.contains(x, y)) return k;
        return null;
    }

    private void handle(Key k, float dx, float dy) {
        if (action == null) return;
        String v = k.value;
        switch (v) {
            case "#del": action.backspace(); return;
            case "#enter": action.enter(); return;
            case "#jp": japanese = true; clipboard = false; invalidate(); return;
            case "#en": japanese = false; clipboard = false; invalidate(); return;
            case "#clip": clipboard = !clipboard; invalidate(); return;
            case "#resize": keyboardHeightDp = keyboardHeightDp > 300 ? 260 : 340; requestLayout(); return;
            case "#paste": pasteClipboard(); return;
            case "#clear": clipboard = false; invalidate(); return;
        }
        if (japanese && v.length() == 1 && !v.equals(" ") && Math.abs(dx) + Math.abs(dy) > dp(20)) {
            action.commit(flick(v, dx, dy));
        } else {
            action.commit(v);
        }
    }

    private String flick(String base, float dx, float dy) {
        String[][] map = { {"あ","い","う","え","お"}, {"か","き","く","け","こ"}, {"さ","し","す","せ","そ"}, {"た","ち","つ","て","と"}, {"な","に","ぬ","ね","の"}, {"は","ひ","ふ","へ","ほ"}, {"ま","み","む","め","も"}, {"や","ゆ","よ","や","よ"}, {"ら","り","る","れ","ろ"}, {"わ","を","ん","ー","わ"} };
        int idx = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 4);
        for (String[] row : map) if (row[0].equals(base)) return row[idx];
        return base;
    }

    private void pasteClipboard() {
        ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = cm != null ? cm.getPrimaryClip() : null;
        if (clip != null && clip.getItemCount() > 0 && action != null) {
            CharSequence text = clip.getItemAt(0).coerceToText(getContext());
            if (text != null) action.commit(text.toString());
        }
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
